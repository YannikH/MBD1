function loadRestaurant(id) {
    $.get("https://api.eet.nu/venues/" + id, function(res) {
        $("#restaurant").find('.name').html(res.name);
        for (var i = res.opening_hours.length - 1; i >= 0; i--) {
            hrs = res.opening_hours[i];
            if(hrs.closed) continue;
            if(typeof hrs.lunch_from != 'undefined') {
                $("#restaurant").find('#opening .' + hrs.day).html(hrs.lunch_from + ' - ' + hrs.lunch_till);
            }
            if(typeof hrs.dinner_from != 'undefined') {
                $("#restaurant").find('#opening .' + hrs.day + 'd').html(hrs.dinner_from + ' - ' + hrs.dinner_till);
            }
        }
        $(".btn.navigate").attr('onClick', 'navigate(' + res.geolocation.latitude + ',' + res.geolocation.longitude + ')');
        getReviews(id);
        $.mobile.changePage('#restaurant');
    });
}

function getReviews(id) {
    $.get("https://api.eet.nu/venues/" + id + "/reviews", function(res) {
        
    });
}

function navigate(lat, long) {
    console.log('navigating to ', lat, long);
    launchnavigator.navigate([lat, long], function(success){
        console.log('success', success);
    }, function(error){
        console.log('error', error);
    });
    console.log('done');
}