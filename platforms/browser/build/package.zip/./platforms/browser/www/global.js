$( document ).on( "pageinit", function() {
	$(document).swiperight(function() {
		if ( $.mobile.activePage.jqmData( "panel" ) !== "open" ) {
			$( "#menuPanel" ).panel( "open" );
		}
	});
    if($(window).width() > 768) {
    //        $( "#menuPanel" ).panel( "open" );
    }
});

document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {
    getStoredUser();
    navigator.geolocation.getCurrentPosition(setUserLocation, failedGeolocation);
}

var setUserLocation = function(position) {
    userpos = position;
    locationFound();
    /*
    alert('Latitude: '          + position.coords.latitude          + '\n' +
          'Longitude: '         + position.coords.longitude         + '\n' +
          'Altitude: '          + position.coords.altitude          + '\n' +
          'Accuracy: '          + position.coords.accuracy          + '\n' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
          'Heading: '           + position.coords.heading           + '\n' +
          'Speed: '             + position.coords.speed             + '\n' +
          'Timestamp: '         + position.timestamp                + '\n');
  */
}

var failedGeolocation = function(error) {
  userpos = {coords: {
    latitude : '51.690507',
    longitude: '5.210189'
  }};
    locationFound();
}