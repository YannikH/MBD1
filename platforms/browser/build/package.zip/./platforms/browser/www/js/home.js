$("#home").on( "pageinit", function(event) {
    initHome();
});

function initHome() {
    randomFav();
}

function randomFav() {
    $(".home-fav").hide();
    getListAdded(user.id, "favourites", true, function(items) {
        var item = items[Math.floor(Math.random()*items.length)];
        $(".home-fav.listRestaurant").attr('onClick', 'loadRestaurant(' + item.id + ')');
        $(".home-fav.listRestaurant h1").html(item.name);
        $(".home-fav.listRestaurant p").html(item.tagline);
        $(".home-fav").show();
    });
}

$("#search").on("touchend", function() {
    //alert('finding near');
    findNear();
});