$("#list").on( "pageshow", function(event) {
    console.log('init list');
    drawList();
});

function drawList() {
    $("#list .restaurantList").empty();
    currentLiked.forEach(function(restaurant) {
        console.log('drawing restaurant');
        restaurantView = $('<div class="listRestaurant" onClick="loadRestaurant(' + restaurant.id + ')" hidden><div class="padding-sides"><h1></h1><p></p></div></div>');
        restaurantView.attr('class', restaurantView.attr('class').replace('template', ''));
        console.log(restaurantView);

        restaurantView.find('h1').html(restaurant.name);
        restaurantView.find('p').html(restaurant.tagline);
        $("#list .restaurantList").append(restaurantView);
        restaurantView.show();
    });
}